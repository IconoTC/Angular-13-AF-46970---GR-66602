import { Component } from '@angular/core';
import { AgendaService } from './services/agenda.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  amigos: any[] = [];
  id: string = '';
  contacto: any;
  mostrar: boolean = false;

  amigoForm = new FormGroup({
    nombre: new FormControl('', [Validators.required, Validators.minLength(3)]),
    telefono: new FormControl('', [Validators.required, Validators.pattern('[6-7]{1}[0-9]{8}')])
  });

  constructor(private agendaService: AgendaService) {
  
    agendaService.getAll().subscribe({
        next: (datos) => { 
          console.log(datos);

          // limpiamos la lista de amigos
          this.amigos = [];

          datos.forEach(item => {
            this.amigos.push(item.payload.doc.data())
          });
        }, error: (error) => { 
          console.error(error) 
        }, complete: () => { 
          console.log('Terminado') 
        } 
    });
  }

  modificar() {
    this.mostrar = true;
    this.amigoForm.setValue(this.contacto);
  }

  guardarCambios(): void {
    this.agendaService.modificar(this.id, this.amigoForm.value)
      .then( () => {
        setTimeout( () => {
          this.mostrar = false;
          this.contacto = null;
          this.id = '';
          this.amigoForm.reset();
          alert("Contacto modificado");
        }, 500)
      })
      .catch( error => {
        console.log(error);
      })
      .finally( () => {
        console.log('Terminado');
      }) 
  }

  borrar() {
    this.agendaService.eliminar(this.id)
      .then( () => {
        this.id = '';
        this.contacto = null;
        alert("Contacto eliminado");
      })
      .catch( error => {
        console.log(error);
      })
      .finally( () => {
        console.log('Terminado');
      }); 
  }

  buscar(): void {
    this.agendaService.buscarAmigo(this.id).subscribe({
      next: (item) => { 
        this.id = item.payload.id;
        this.contacto = item.payload.data()
      }, error: (error) => { 
        console.error(error) 
      }, complete: () => { 
        console.log('Terminado') 
      } 
    });
  }

  alta(): void {
    this.agendaService.nuevoAmigo(this.amigoForm.value)
      .then( () => {
        // limpiar el formulario
        this.amigoForm.reset();
        alert("Contacto creado");
      })
      .catch( error => {
        console.log(error);
      })
      .finally( () => {
        console.log("Terminado")
      });   
  }
}
