// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: "AIzaSyDXTIEBq8FxqVlJsMxTle7bAQQmyY6ocoQ",
    authDomain: "angular-indra-anabel-15-nov.firebaseapp.com",
    projectId: "angular-indra-anabel-15-nov",
    storageBucket: "angular-indra-anabel-15-nov.firebasestorage.app",
    messagingSenderId: "384878531015",
    appId: "1:384878531015:web:0a23a5ddaec8efb2ccc9e2"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
