export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyDXTIEBq8FxqVlJsMxTle7bAQQmyY6ocoQ",
    authDomain: "angular-indra-anabel-15-nov.firebaseapp.com",
    projectId: "angular-indra-anabel-15-nov",
    storageBucket: "angular-indra-anabel-15-nov.firebasestorage.app",
    messagingSenderId: "384878531015",
    appId: "1:384878531015:web:0a23a5ddaec8efb2ccc9e2"
  }
};
