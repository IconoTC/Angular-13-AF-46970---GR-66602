import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ContactoService {

  constructor() { }

  enviar(datos: any): void{
    console.log(datos);
  }
}
