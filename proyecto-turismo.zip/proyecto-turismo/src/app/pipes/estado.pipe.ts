import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'estado'
})
export class EstadoPipe implements PipeTransform {

  transform(value: unknown, ...args: unknown[]): unknown {

    if (value){
      return "Abierto"
    } else {
      return "Cerrado";
    }
    
  }

}
